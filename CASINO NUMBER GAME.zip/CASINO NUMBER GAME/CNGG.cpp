#include <iostream>
using namespace std;

int main()
{
	  int secretNum = 5;
	  int guess;
	  int guessLimit = 2;
	  int guessCount = 0;
	  bool outOfGuesses = false;
	  
	  while(secretNum != guess && !outOfGuesses) {
	  	if(guessCount < guessLimit) {
	  		cout << "Enter guess:  ";
	  		cin >> guess;
	  		guessCount++;
		  } else {
		  	outOfGuesses = true;
		  }
	  } 
	  if(outOfGuesses) {
	  	cout << "You Lose!";
	  } else {
	  	cout << "You Win!";
	  }
}
    	
      
